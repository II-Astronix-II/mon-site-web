import pygame
from pathlib import Path
import re


ASSETS_PATH = Path("assets")

class Player(pygame.sprite.Sprite):
    """
    Classe représentant le joueur.
    Input: pos (tuple) - la position initiale du joueur
    """
    def __init__(self, pos):
        super().__init__()

        self.scale = 0.5   #redimentionne le joueur

        self.animations = {
            "idle_front": self.load_frames("player_afk", "front"),
            "idle_back": self.load_frames("player_afk", "back"),
            "idle_left": self.load_frames("player_afk", "left"),
            "idle_right": self.load_frames("player_afk", "right"),

            "walk_front": self.load_frames("player_walk", "front"),
            "walk_back": self.load_frames("player_walk", "back"),
            "walk_left": self.load_frames("player_walk", "left"),
            "walk_right": self.load_frames("player_walk", "right"),
        }

        
        self.state = "idle"
        self.facing = "front"
        self.frame_index = 0.0
        self.anim_key = f"{self.state}_{self.facing}"
        self.idle_fps = 6 #fps animation afk (plus c'est bas plus c'est lent)
        self.walk_fps = 8 #fps animation deplacement 


        key = f"{self.state}_{self.facing}"
        self.image = self.animations[key][0]
        self.rect = self.image.get_rect(center=pos)
        # hitbox 
        self.hitbox = self.rect.copy()
        self.hitbox.inflate_ip(-self.rect.width * 0.8, -self.rect.height * 0.64)



        self.direction = pygame.Vector2(0, 0)
        self.speed = 50     #pixel par s
    


    def load_frames(self, folder, direction):
        """
        Méthode qui charge les frames d'animation du joueur.
        Input: folder (str) - le dossier contenant les images
               direction (str) - la direction des images à charger
        Output: frames (list) - liste des images chargées
        """
        
        folder_path = ASSETS_PATH / folder
        files = [
            p for p in folder_path.iterdir()
            if p.suffix.lower() == ".png" and direction in p.stem
        ]
    
        def frame_number(path):
                
                m = re.search(r"(\d+)$", path.stem)
                return int(m.group(1)) if m else 0

        frames = []
        for img_path in sorted(files, key=frame_number):
            img = pygame.image.load(img_path).convert_alpha()

            
            w = int(img.get_width() * self.scale)
            h = int(img.get_height() * self.scale)
            img = pygame.transform.smoothscale(img, (w, h))

            frames.append(img)

        return frames

    
    def handle_input(self):
        """
        Méthode qui gère les entrées utilisateur.
        """
        keys = pygame.key.get_pressed()

        x = 0
        y = 0

        # deplacement
        if keys[pygame.K_q]:
            x -= 1
        if keys[pygame.K_d]:
            x += 1
        if keys[pygame.K_z]:
            y -= 1
        if keys[pygame.K_s]:
            y += 1

        self.direction = pygame.Vector2(x, y)
        if self.direction.length_squared() > 0:
            self.state = "walk"

            if abs(self.direction.x) > abs(self.direction.y):
                self.facing = "right" if self.direction.x > 0 else "left"
            else:
                self.facing = "front" if self.direction.y > 0 else "back"
        else:
            self.state = "idle"

        new_key = f"{self.state}_{self.facing}"
        if new_key != self.anim_key:
            self.anim_key = new_key
            self.frame_index = 0.0
    
    def move(self, dt: float, obstacles):
        """
        Méthode qui gère le déplacement du joueur avec les collisions. Appelée à chaque frame.
        Input: dt (float) - le temps écoulé depuis la dernière frame
               obstacles (list) - liste des rectangles des obstacles
        """
        
        if self.direction.length_squared() > 0:
            self.direction = self.direction.normalize()

        self.rect.x += self.direction.x * self.speed * dt
        self.rect.y += self.direction.y * self.speed * dt

        # Mouvement X
        self.hitbox.x += self.direction.x * self.speed * dt
        obstacle = self.collide(obstacles)
        if obstacle:
            if self.direction.x > 0:  # va à droite
                self.hitbox.right = obstacle.left
            elif self.direction.x < 0:  # va à gauche
                self.hitbox.left = obstacle.right

        # Mouvement Y
        self.hitbox.y += self.direction.y * self.speed * dt
        obstacle = self.collide(obstacles)
        if obstacle:
            if self.direction.y > 0:  # va en bas
                self.hitbox.bottom = obstacle.top
            elif self.direction.y < 0:  # va en haut
                self.hitbox.top = obstacle.bottom

        self.rect.center = self.hitbox.center

    def animate(self, dt: float):
        """
        Méthode qui gère l'animation du joueur. Appelée à chaque frame.
        Input: dt (float) - le temps écoulé depuis la dernière frame
        """

        frames = self.animations[self.anim_key]
        if not frames:
            return

        fps = self.idle_fps if self.state == "idle" else self.walk_fps

        self.frame_index += fps * dt
        if self.frame_index >= len(frames):
            self.frame_index = 0.0

        self.image = frames[int(self.frame_index)]

    def collide(self, obstacles):
        """
        Méthode qui vérifie les collisions du joueur avec les obstacles.
        Input: obstacles (list) - liste des rectangles des obstacles
        Output: obstacle (pygame.Rect) - le rectangle de l'obstacle en collision, ou None s'il n'y a pas de collision
        """

        for obstacle in obstacles:
            if self.hitbox.colliderect(obstacle):
                return obstacle
        return None


    def update(self, dt: float, obstacles):
        """
        Méthode qui met à jour tous les éléments du jeu. Appelée à chaque frame.
        Input: dt (float) - le temps écoulé depuis la dernière frame
        """

        self.handle_input()
        self.move(dt, obstacles)
        self.animate(dt)
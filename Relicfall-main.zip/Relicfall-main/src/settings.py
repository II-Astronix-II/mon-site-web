#Les couleurs
WHITE = (255, 255, 255)
LIGHT_GRAY = (200, 200, 200)
GRAY = (160, 160, 160)
BLACK = (0, 0, 0)

#Les couleurs des différents types de blocs
COLOR_MAP = [(255,255,255),(0,0,0),(127,127,127),(163,73,164),(0,162,232),(63,72,204),(34,177,76),(195,195,195),(237,28,36),(181,230,29),(255,242,0),(255,201,14)]

#le nombre de salles par niveau
ROOM_LEVEL = [2,2]

FPS= 60


import pygame
from menu.welcome import MainMenu
from settings import *
import sys

class MainApp :
    def __init__(self):

        pygame.init()


        self.running = True
        self.screen = pygame.display.set_mode((1280, 720))
        self.clock = pygame.time.Clock()

        #Les polices
        self.font = pygame.font.SysFont(None, 70)
        self.font_small = pygame.font.SysFont(None, 50)


        #Le menu principal
        self.current_screen = MainMenu(self)


    #La boucle de jeu principale
    def run(self):
        while self.running:
            self.screen.fill((50, 80, 200))

            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    if hasattr(self.current_screen, "save"):
                        self.current_screen.save()
                    pygame.quit()
                    sys.exit()
                else:
                    self.current_screen.handle_event(event)

            dt = self.clock.tick(FPS) / 1000
            if hasattr(self.current_screen, "update"):
                self.current_screen.update(dt)
            self.current_screen.draw()

            pygame.display.update()
            
        pygame.quit()



if __name__ == "__main__":
    app = MainApp()
    app.run()
    
import pygame
import sys
from settings import *
import json
import os
from entities.player import Player



def ceer_world(name : str) -> list:
    """
    Fonction qui crée un monde vide avec des murs autour et le sauvegarde.
    Input: name (str) - le nom du monde à créer
    Output: monde (list) - la représentation du monde sous forme de liste 2D
    """

    largeur = 1280 // 16
    hauteur = 720 // 16
    monde = []
    for x in range(hauteur):
        ligne = []
        for y in range(largeur):
            if x == 0 or x == hauteur -1 or y == 0 or y == largeur -1:
                ligne.append(1)
            else:
                ligne.append(0)
        monde.append(ligne)

    with open(f"worlds/world_{name}.json", "w", encoding="utf-8") as f:
        json.dump(monde, f, indent=4)
    return monde








class Game:
    """
    C'est la classe principale du jeu. (joueur + monde + etc)
    """

    def __init__(self, app,world_name="default"):
        self.app = app
        self.screen = app.screen
        self.font = app.font
        self.font_small = app.font_small
        self.world_name = world_name

        pygame.display.set_caption("Relicfall - Game")

        #Charger le monde
        self.data = self.charger_data()
        self.world = self.charger_lobby(self.data["lobby"])
        self.room = 0

        #Sauvegarder les hitbox
        self.hitboxes = []
        self.update_hitboxes()

        self.player = pygame.sprite.GroupSingle(Player((self.world["spawn"][0]*16, self.world["spawn"][1]*16)))


    def charger_data(self) -> dict:
        """
        Méthode qui charge les données d'un monde depuis un fichier JSON.
        Output: data (list) - les données du monde
        """
        with open(f"worlds/{self.world_name}/save.json", "r", encoding="utf-8") as f:
            data = json.load(f)
        return data


    def charger_lobby(self,num : int) -> dict:
        """
        Méthode qui charge les données d'un monde depuis un fichier JSON.
        Input: name (str) - le nom de la sauvegarde à charger
        Output: data (list) - les données du monde
        """
        with open(f"worlds/{self.world_name}/lobby/lobby_{num}.json", "r", encoding="utf-8") as f:
            world = json.load(f)
        return world

    def charger_level(self) -> dict:
        """
        Méthode qui charge les données d'un niveau depuis un fichier JSON.
        Input: name (str) - le nom de la sauvegarde à charger
        Output: data (list) - les données du niveau
        """
        with open(f"worlds/{self.world_name}/niveau_{self.data['lobby']}/salle_{self.room}.json", "r", encoding="utf-8") as f:
            level = json.load(f)
        self.room +=1
        return level

    def update_hitboxes(self):
        """
        Méthode qui met à jour les hitbox du monde.
        """

        self.hitboxes = []
        for y in range(len(self.world["world"])):
            for x in range(len(self.world["world"][y])):
                if self.world["world"][y][x] in [1,2,4,5,6]:
                    rect = pygame.Rect(x*16, y*16, 16, 16)
                    self.hitboxes.append(rect)

    def draw(self):
        """
        Méthode qui dessine tous les éléments du jeu. Appelée à chaque frame.
        """

        for x in range(len(self.world["world"])):
            for y in range(len(self.world["world"][x])):
                n = self.world["world"][x][y]
                pygame.draw.rect(self.screen, COLOR_MAP[n], (y*16, x*16, 16, 16))
        self.player.draw(self.screen)



    def handle_event(self, event):
        """
        Méthode appelé à chaque événement. Gère les entrées utilisateur.
        Input: event (pygame.event) - l'événement à gérer
        """
        
        if event.type == pygame.QUIT:
            pygame.quit()
            sys.exit()

        if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
            from menu.welcome import MainMenu
            self.app.current_screen = MainMenu(self.app)

    def respawn_player(self):
        """
        Méthode qui respawn le joueur au point de spawn.
        """

        spawn_center = (self.world["spawn"][0]*16, self.world["spawn"][1]*16)
        self.player.sprite.rect.center = spawn_center
        if hasattr(self.player.sprite, "hitbox"):
            self.player.sprite.hitbox.center = spawn_center

    def update(self, dt):
        """
        Méthode qui met à jour tous les éléments du jeu. Appelée à chaque frame.
        Input: dt (float) - le temps écoulé depuis la dernière frame
        """
        self.player.update(dt, self.hitboxes)

        for x,y in self.world["exit"]:
            if self.player.sprite.rect.center[0] >= x*16 and self.player.sprite.rect.center[0] < x*16 +16:
                if self.player.sprite.rect.center[1] >= y*16 and self.player.sprite.rect.center[1] < y*16 +16:
                    if self.room < ROOM_LEVEL[self.data["lobby"]-1]:
                        self.world = self.charger_level()
                        self.update_hitboxes()
                        self.respawn_player()

                    else:
                        self.data["lobby"] +=1
                        self.room = 0
                        self.world = self.charger_lobby(self.data["lobby"])
                        self.update_hitboxes()
                        self.respawn_player()

    def save(self):
        """
        Méthode appelé lors de la fermeture du jeu.
        """
        with open(f"worlds/{self.world_name}/save.json", "w", encoding="utf-8") as f:
            json.dump(self.data, f, indent=4)
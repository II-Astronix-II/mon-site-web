import pygame
from settings import *

class Button:
    """
    Classe pour créer des boutons cliquables.
    Input: text (str) - le texte du bouton
           font (pygame.font) - la police du texte
           x (int) - la position x du bouton
           y (int) - la position y du bouton
           screen (pygame.Surface) - la surface où dessiner le bouton
           call_back (function) - la fonction à appeler lors du clic
           highlight (bool) - si le bouton doit être mis en surbrillance au survol
    """
    def __init__(self,text,font, x, y,screen,call_back, highlight=True):
        self.draw_text = text
        self.font = font
        self.x = x
        self.y = y
        self.pressed = False
        self.screen = screen
        self.call_back = call_back
        self.highlight = highlight


        self.surface = font.render(self.draw_text, True, WHITE)
        self.rect = self.surface.get_rect(center=(self.x, self.y))
    
    def draw(self):
        """
        Méthode qui dessine tous les éléments du jeu. Appelée à chaque frame.
        """

        if self.highlight:
            mouse_pos = pygame.mouse.get_pos()
            color = LIGHT_GRAY if self.x-50 < mouse_pos[0] < self.x+50 and self.y-20 < mouse_pos[1] < self.y+20 else WHITE
            self.surface = self.font.render(self.draw_text, True, color)
            self.rect = self.surface.get_rect(center=(self.x, self.y))

        self.screen.blit(self.surface, self.rect)

    def callback(self):
        """
        Méthode appelé lors du clic sur le bouton.
        """
        
        return self.call_back()



def draw_text(text, font, x, y, screen, highlight=True):
    """Fonction pour dessiner du texte centré et renvoyer sa hitbox"""
    if highlight:
        mouse_pos = pygame.mouse.get_pos()
        color = LIGHT_GRAY if x-50 < mouse_pos[0] < x+50 and y-20 < mouse_pos[1] < y+20 else WHITE
    else:
        color = WHITE

    surface = font.render(text, True, color)
    rect = surface.get_rect(center=(x, y))
    screen.blit(surface, rect)
    return rect
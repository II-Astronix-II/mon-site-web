import pygame
from settings import *
import sys
from menu.play import PlayMenu
from menu.ui import *



class MainMenu:
    """
    Menu principal du jeu
    Inputs: app - instance de MainApp
    """


    def __init__(self, app):

        self.app = app
        self.screen = app.screen
        self.font = app.font
        self.font_small = app.font_small

        pygame.display.set_caption("Relicfall - Menu Principal")
        self.buttons = []
        self.buttons.append(Button("Jouer", self.font_small, 640, 300, self.screen,self.jouer))
        self.buttons.append(Button("Option", self.font_small, 640, 400, self.screen,self.option))
        self.buttons.append(Button("Crédit", self.font_small, 640, 500, self.screen,self.credit))
        self.buttons.append(Button("Quitter", self.font_small, 150, 650, self.screen,self.quitter))

    def draw(self):
        """
        Méthode qui dessine tous les éléments du jeu. Appelée à chaque frame.
        """
        
        self.screen.fill((30, 30, 30))


        draw_text("RELICFALL", self.font, 640, 150, self.screen,False)

        for button in self.buttons:
            button.draw()

    def handle_event(self, event):
        """
        Méthode appelé à chaque événement. Gère les entrées utilisateur.
        Input: event (pygame.event) - l'événement à gérer
        """

        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.buttons[0].rect.collidepoint(event.pos):
                self.buttons[0].callback()

            if self.buttons[3].rect.collidepoint(event.pos):
                self.buttons[3].callback()
    

    def jouer(self):
        """
        Méthode appelée lors du clic sur le bouton "Jouer".
        """

        self.app.current_screen = PlayMenu(self.app)
    
    def option(self):
        """
        Méthode appelée lors du clic sur le bouton "Option".
        """

        pass

    def credit(self):
        """
        Méthode appelée lors du clic sur le bouton "Crédit".
        """

        pass
    
    def quitter(self):
        """
        Méthode appelée lors du clic sur le bouton "Quitter".
        """

        pygame.quit()
        sys.exit()
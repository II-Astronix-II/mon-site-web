import pygame
from settings import *
from game import Game
from menu.ui import *

class PlayMenu:
    """
    Classe représentant le menu de jeu.
    Input: app (MainApp) - l'application principale
    """

    def __init__(self, app):

        self.app = app
        self.screen = app.screen
        self.font = app.font
        self.font_small = app.font_small

        pygame.display.set_caption("Relicfall - Menu jouer")

        self.buttons = []
        self.buttons.append(Button("Créer", self.font_small, 640, 300, self.screen,self.creer))
        self.buttons.append(Button("Charger", self.font_small, 640, 400, self.screen,self.charger))
        self.buttons.append(Button("Rejoindre", self.font_small, 640, 500, self.screen,self.rejoindre))
        self.buttons.append(Button("Retour", self.font_small, 150, 650, self.screen,self.retour))

    def draw(self):
        """
        Méthode qui dessine tous les éléments du jeu. Appelée à chaque frame.
        """

        self.screen.fill((30, 30, 30))


        draw_text("RELICFALL", self.font, 640, 150, self.screen,False)

        for button in self.buttons:
            button.draw()

    def handle_event(self, event):
        """
        Méthode appelé à chaque événement. Gère les entrées utilisateur.
        Input: event (pygame.event) - l'événement à gérer
        """

        if event.type == pygame.MOUSEBUTTONDOWN:
            if self.buttons[0].rect.collidepoint(event.pos):
                self.buttons[0].callback()

            if self.buttons[3].rect.collidepoint(event.pos):
                self.buttons[3].callback()

    def creer(self):
        """
        Méthode appelée lors du clic sur le bouton "Créer".
        """
        self.app.current_screen = Game(self.app)
    
    def charger(self):
        """
        Méthode appelée lors du clic sur le bouton "Charger".
        """
        pass

    def rejoindre(self):
        """
        Méthode appelée lors du clic sur le bouton "Rejoindre".
        """
        pass

    def retour(self):
        """
        Méthode appelée lors du clic sur le bouton "Retour"."
        """
        
        from menu.welcome import MainMenu
        self.app.current_screen = MainMenu(self.app)